-- Add password protection and downloads toggle to albums (SQLite)
-- Columns already exist, skip
-- password_hash and allow_downloads already added

