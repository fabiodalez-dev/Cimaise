-- Add show_date flag to albums (SQLite)
-- Column already exists, skip

