<?php
declare(strict_types=1);

// Entry point when server docroot is repository root.
// Forward to public/index.php
require __DIR__ . '/public/index.php';

